Installation guide and general information at "http://gibaholms.wordpress.com".

-----
Version 1.1
Release notes:
1. New property "wsaEnabled", to enable or disable WSA Filter Mock
2. Login page showing after login target page
3. Logout URL and default page, supporting redirect
4. Propagate query strings after login and logout on redirects
5. URLs encode/decode on redirect flows
-----

by Gilberto Holms.